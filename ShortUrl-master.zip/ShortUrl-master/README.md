# ShortUrl

Dumb side project I did because I was bored.
